﻿namespace student
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.stdname = new System.Windows.Forms.TextBox();
            this.stdID = new System.Windows.Forms.TextBox();
            this.stdage = new System.Windows.Forms.TextBox();
            this.maleradio = new System.Windows.Forms.RadioButton();
            this.femaleradio = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.courselist = new System.Windows.Forms.ListBox();
            this.extra_curricular = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.resultlabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(391, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(391, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Student ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(391, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Student age";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // stdname
            // 
            this.stdname.Location = new System.Drawing.Point(503, 152);
            this.stdname.Name = "stdname";
            this.stdname.Size = new System.Drawing.Size(222, 26);
            this.stdname.TabIndex = 3;
            // 
            // stdID
            // 
            this.stdID.Location = new System.Drawing.Point(503, 205);
            this.stdID.Name = "stdID";
            this.stdID.Size = new System.Drawing.Size(222, 26);
            this.stdID.TabIndex = 4;
            // 
            // stdage
            // 
            this.stdage.Location = new System.Drawing.Point(503, 260);
            this.stdage.Name = "stdage";
            this.stdage.Size = new System.Drawing.Size(222, 26);
            this.stdage.TabIndex = 5;
            // 
            // maleradio
            // 
            this.maleradio.AutoSize = true;
            this.maleradio.Location = new System.Drawing.Point(431, 314);
            this.maleradio.Name = "maleradio";
            this.maleradio.Size = new System.Drawing.Size(68, 24);
            this.maleradio.TabIndex = 6;
            this.maleradio.TabStop = true;
            this.maleradio.Text = "male";
            this.maleradio.UseVisualStyleBackColor = true;
            // 
            // femaleradio
            // 
            this.femaleradio.AutoSize = true;
            this.femaleradio.Location = new System.Drawing.Point(599, 314);
            this.femaleradio.Name = "femaleradio";
            this.femaleradio.Size = new System.Drawing.Size(82, 24);
            this.femaleradio.TabIndex = 7;
            this.femaleradio.TabStop = true;
            this.femaleradio.Text = "female";
            this.femaleradio.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::student.Properties.Resources.NikeLogoPNGImage;
            this.pictureBox1.Location = new System.Drawing.Point(489, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(236, 119);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // courselist
            // 
            this.courselist.FormattingEnabled = true;
            this.courselist.ItemHeight = 20;
            this.courselist.Items.AddRange(new object[] {
            "java",
            "c#",
            "orcl",
            "english"});
            this.courselist.Location = new System.Drawing.Point(294, 364);
            this.courselist.Name = "courselist";
            this.courselist.Size = new System.Drawing.Size(138, 124);
            this.courselist.TabIndex = 9;
            // 
            // extra_curricular
            // 
            this.extra_curricular.AutoSize = true;
            this.extra_curricular.Location = new System.Drawing.Point(528, 374);
            this.extra_curricular.Name = "extra_curricular";
            this.extra_curricular.Size = new System.Drawing.Size(141, 24);
            this.extra_curricular.TabIndex = 10;
            this.extra_curricular.Text = "Extra-curricular";
            this.extra_curricular.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(449, 519);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 49);
            this.button1.TabIndex = 11;
            this.button1.Text = "submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(599, 519);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(106, 49);
            this.button2.TabIndex = 12;
            this.button2.Text = "clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(756, 519);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(106, 49);
            this.button3.TabIndex = 13;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // resultlabel
            // 
            this.resultlabel.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.resultlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultlabel.Location = new System.Drawing.Point(576, 594);
            this.resultlabel.Name = "resultlabel";
            this.resultlabel.Size = new System.Drawing.Size(202, 98);
            this.resultlabel.TabIndex = 14;
            this.resultlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1461, 721);
            this.Controls.Add(this.resultlabel);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.extra_curricular);
            this.Controls.Add(this.courselist);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.femaleradio);
            this.Controls.Add(this.maleradio);
            this.Controls.Add(this.stdage);
            this.Controls.Add(this.stdID);
            this.Controls.Add(this.stdname);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox stdname;
        private System.Windows.Forms.TextBox stdID;
        private System.Windows.Forms.TextBox stdage;
        private System.Windows.Forms.RadioButton maleradio;
        private System.Windows.Forms.RadioButton femaleradio;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListBox courselist;
        private System.Windows.Forms.CheckBox extra_curricular;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label resultlabel;
    }
}

