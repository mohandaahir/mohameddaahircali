﻿namespace online
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.femaleButton = new System.Windows.Forms.RadioButton();
            this.maleButton = new System.Windows.Forms.RadioButton();
            this.StdAgetextBox = new System.Windows.Forms.TextBox();
            this.Std_IDtextBox = new System.Windows.Forms.TextBox();
            this.StdNametextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Extra_curricular = new System.Windows.Forms.CheckBox();
            this.Resultlabel = new System.Windows.Forms.Label();
            this.submitbutton = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.courselist = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::online.Properties.Resources.images__1_;
            this.pictureBox1.Location = new System.Drawing.Point(305, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(165, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Controls.Add(this.femaleButton);
            this.groupBox1.Controls.Add(this.maleButton);
            this.groupBox1.Controls.Add(this.StdAgetextBox);
            this.groupBox1.Controls.Add(this.Std_IDtextBox);
            this.groupBox1.Controls.Add(this.StdNametextBox);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(305, 139);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(364, 276);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBoxStudentInfo";
            // 
            // femaleButton
            // 
            this.femaleButton.AutoSize = true;
            this.femaleButton.Location = new System.Drawing.Point(206, 220);
            this.femaleButton.Name = "femaleButton";
            this.femaleButton.Size = new System.Drawing.Size(87, 24);
            this.femaleButton.TabIndex = 7;
            this.femaleButton.TabStop = true;
            this.femaleButton.Text = "Female";
            this.femaleButton.UseVisualStyleBackColor = true;
            // 
            // maleButton
            // 
            this.maleButton.AutoSize = true;
            this.maleButton.Location = new System.Drawing.Point(65, 220);
            this.maleButton.Name = "maleButton";
            this.maleButton.Size = new System.Drawing.Size(68, 24);
            this.maleButton.TabIndex = 6;
            this.maleButton.TabStop = true;
            this.maleButton.Text = "Male";
            this.maleButton.UseVisualStyleBackColor = true;
            // 
            // StdAgetextBox
            // 
            this.StdAgetextBox.Location = new System.Drawing.Point(137, 150);
            this.StdAgetextBox.Name = "StdAgetextBox";
            this.StdAgetextBox.Size = new System.Drawing.Size(206, 26);
            this.StdAgetextBox.TabIndex = 5;
            // 
            // Std_IDtextBox
            // 
            this.Std_IDtextBox.Location = new System.Drawing.Point(137, 98);
            this.Std_IDtextBox.Name = "Std_IDtextBox";
            this.Std_IDtextBox.Size = new System.Drawing.Size(206, 26);
            this.Std_IDtextBox.TabIndex = 4;
            // 
            // StdNametextBox
            // 
            this.StdNametextBox.Location = new System.Drawing.Point(137, 50);
            this.StdNametextBox.Name = "StdNametextBox";
            this.StdNametextBox.Size = new System.Drawing.Size(206, 26);
            this.StdNametextBox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Student Age";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Student ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Name";
            // 
            // Extra_curricular
            // 
            this.Extra_curricular.AutoSize = true;
            this.Extra_curricular.Location = new System.Drawing.Point(489, 431);
            this.Extra_curricular.Name = "Extra_curricular";
            this.Extra_curricular.Size = new System.Drawing.Size(143, 24);
            this.Extra_curricular.TabIndex = 7;
            this.Extra_curricular.Text = "extra_curricular";
            this.Extra_curricular.UseVisualStyleBackColor = true;
            // 
            // Resultlabel
            // 
            this.Resultlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Resultlabel.Location = new System.Drawing.Point(489, 468);
            this.Resultlabel.Name = "Resultlabel";
            this.Resultlabel.Size = new System.Drawing.Size(280, 147);
            this.Resultlabel.TabIndex = 8;
            this.Resultlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // submitbutton
            // 
            this.submitbutton.Location = new System.Drawing.Point(352, 618);
            this.submitbutton.Name = "submitbutton";
            this.submitbutton.Size = new System.Drawing.Size(103, 42);
            this.submitbutton.TabIndex = 9;
            this.submitbutton.Text = "submit";
            this.submitbutton.UseVisualStyleBackColor = true;
            this.submitbutton.Click += new System.EventHandler(this.submitbutton_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(473, 618);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(87, 42);
            this.Clearbutton.TabIndex = 10;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(606, 618);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(87, 42);
            this.Exitbutton.TabIndex = 11;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // courselist
            // 
            this.courselist.FormattingEnabled = true;
            this.courselist.ItemHeight = 20;
            this.courselist.Items.AddRange(new object[] {
            "java",
            "arabic",
            "orcl",
            "c#",
            ""});
            this.courselist.Location = new System.Drawing.Point(249, 431);
            this.courselist.Name = "courselist";
            this.courselist.Size = new System.Drawing.Size(174, 164);
            this.courselist.TabIndex = 12;
            this.courselist.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 719);
            this.Controls.Add(this.courselist);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.submitbutton);
            this.Controls.Add(this.Resultlabel);
            this.Controls.Add(this.Extra_curricular);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox StdAgetextBox;
        private System.Windows.Forms.TextBox Std_IDtextBox;
        private System.Windows.Forms.TextBox StdNametextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton femaleButton;
        private System.Windows.Forms.RadioButton maleButton;
        private System.Windows.Forms.CheckBox Extra_curricular;
        private System.Windows.Forms.Label Resultlabel;
        private System.Windows.Forms.Button submitbutton;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.ListBox courselist;
    }
}

